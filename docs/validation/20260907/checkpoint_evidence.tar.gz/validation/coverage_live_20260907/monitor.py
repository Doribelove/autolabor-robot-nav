#!/usr/bin/env python3
"""Passive experiment recorder: no control publishers or service calls."""
import collections
import datetime
import hashlib
import json
import os
import subprocess
import threading
import time
from pathlib import Path
import roslib.message
import rospy

HERE = Path(__file__).resolve().parent
RUN = HERE / datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
RUN.mkdir()
(HERE / 'latest_run.txt').write_text(str(RUN) + '\n')
lock = threading.RLock()
events = open(str(RUN / 'events.jsonl'), 'a', buffering=1)
counts = collections.Counter()
last_seen = {}
latest = {}
signatures = {}
velocity = {}
subs = {}

def plain(msg):
    if isinstance(msg, (list, tuple)):
        return [plain(x) for x in msg]
    if hasattr(msg, '__slots__'):
        return {slot: plain(getattr(msg, slot)) for slot in msg.__slots__}
    return msg

def emit(kind, **kwargs):
    with lock:
        events.write(json.dumps(dict(ts=time.time(), kind=kind, **kwargs), ensure_ascii=False) + '\n')

def callback(msg, topic):
    now = time.time()
    with lock:
        counts[topic] += 1
        prior_seen = last_seen.get(topic)
        last_seen[topic] = now
        if msg._type == 'geometry_msgs/Twist' or topic.endswith('_wheel_vel'):
            if hasattr(msg, 'linear'):
                values = [msg.linear.x, msg.linear.y, msg.angular.z]
            else:
                values = [msg.data]
            row = velocity.setdefault(topic, dict(count=0, nonzero=0, max_abs=[0.] * len(values),
                                                   max_arrival_gap_sec=0.))
            row['count'] += 1
            if prior_seen is not None:
                gap = now - prior_seen
                row['max_arrival_gap_sec'] = max(row['max_arrival_gap_sec'], gap)
                if gap >= .15:
                    emit('velocity_arrival_gap', topic=topic, gap_sec=gap)
            row['max_abs'] = [max(a, abs(b)) for a, b in zip(row['max_abs'], values)]
            if any(abs(v) > 1e-6 for v in values):
                row['nonzero'] += 1
                emit('velocity_nonzero', topic=topic, msg=plain(msg))
            return
        if msg._type == 'nav_msgs/Path':
            points = [[p.pose.position.x, p.pose.position.y, p.pose.orientation.z,
                       p.pose.orientation.w] for p in msg.poses]
            signature = hashlib.sha256(json.dumps(points).encode()).hexdigest()
            latest[topic] = dict(n=len(points), frame=msg.header.frame_id, signature=signature,
                                 start=points[0] if points else None, end=points[-1] if points else None)
            if signatures.get(topic) != signature:
                emit('path_change', topic=topic, msg=plain(msg))
                signatures[topic] = signature
            return
        if topic == '/rosout_agg':
            if msg.level >= 4 or msg.name in ('/coverage_manager', '/move_base'):
                emit('rosout', topic=topic, msg=plain(msg))
            return
        data = plain(msg)
        latest[topic] = data
        if topic in ('/odom', '/Odometry'):
            emit('odometry', topic=topic, msg=data)
            return
        if msg._type.endswith('ActionFeedback') or msg._type.endswith('ActionResult') or msg._type.endswith('ActionGoal'):
            emit('action', topic=topic, msg=data)
            return
        check = {k: v for k, v in data.items() if k != 'header'} if isinstance(data, dict) else data
        if signatures.get(topic) != check:
            emit('state_change', topic=topic, msg=data)
            signatures[topic] = check

def wanted(topic, typ):
    return (topic.startswith('/coverage/') and typ != 'visualization_msgs/MarkerArray'
            or '/plan_hybrid_transitions/' in topic
            or topic.startswith('/cmd_vel')
            or topic in ('/odom', '/Odometry', '/m2_driver/left_wheel_vel', '/m2_driver/right_wheel_vel',
                         '/m2_driver/control_timeout', '/m2_driver/chassis_info', '/m2_driver/chassis_monitor',
                         '/fast_lio/localization_status', '/nvidia_cmd_vel_watchdog/status',
                         '/autolabor_operator_gui/map_display_status', '/rosout_agg',
                         '/move_base/goal', '/move_base/status', '/move_base/result', '/move_base/feedback')
            or (topic.startswith('/move_base/') and typ == 'nav_msgs/Path'))

def cpu_worker():
    err = open(str(RUN / 'cpu_ssh.stderr'), 'a')
    with open(str(HERE / 'j6m_cpu.py')) as source, open(str(RUN / 'j6m_cpu.jsonl'), 'a', buffering=1) as output:
        proc = subprocess.Popen(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                                 '-o', 'ServerAliveInterval=10', '-o', 'ServerAliveCountMax=3',
                                 'root@192.168.10.100', 'python3', '-u', '-'],
                                stdin=source, stdout=subprocess.PIPE, stderr=err, universal_newlines=True)
        for line in proc.stdout:
            try:
                row = json.loads(line)
                row['received_ts'] = time.time()
                output.write(json.dumps(row) + '\n')
                with lock:
                    latest['j6m_cpu'] = row
            except ValueError:
                emit('cpu_parse_error', text=line)
        emit('cpu_collector_exit', returncode=proc.wait())

rospy.init_node('coverage_experiment_passive_monitor', anonymous=True)
emit('monitor_start', pid=os.getpid(), output=str(RUN), cpu_interval_sec=.25,
     note='100% process/thread CPU equals one core; transient threads may fall between samples')
threading.Thread(target=cpu_worker, daemon=True).start()
next_discovery = 0
while not rospy.is_shutdown():
    if time.monotonic() >= next_discovery:
        try:
            for topic, typ in rospy.get_published_topics():
                if topic not in subs and wanted(topic, typ):
                    cls = roslib.message.get_message_class(typ)
                    if cls:
                        subs[topic] = rospy.Subscriber(topic, cls, callback, callback_args=topic, queue_size=100)
                        emit('subscribe', topic=topic, type=typ)
        except Exception as error:
            emit('discovery_error', error=str(error))
        next_discovery = time.monotonic() + 5
    with lock:
        snapshot = dict(ts=time.time(), counts=dict(counts),
                        age_sec={k: round(time.time()-v, 3) for k,v in last_seen.items()},
                        velocity=velocity, latest=latest)
        temporary = RUN / 'latest.json.tmp'
        temporary.write_text(json.dumps(snapshot, ensure_ascii=False))
        temporary.replace(RUN / 'latest.json')
        emit('heartbeat', counts=dict(counts), velocity=velocity,
             coverage=latest.get('/coverage/status'), cpu=latest.get('j6m_cpu'))
        velocity = {}
    time.sleep(1)
