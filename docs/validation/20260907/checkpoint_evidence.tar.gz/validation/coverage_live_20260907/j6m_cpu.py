#!/usr/bin/env python3
"""Read-only /proc sampling, streamed over SSH; percent=one CPU core."""
import json
import os
import time

HZ = os.sysconf('SC_CLK_TCK')
PAGE = os.sysconf('SC_PAGE_SIZE')
ROOT = '/map/robot_j6m_navigation_20260907'
previous = {}
targets = {}
last_scan = 0
last_time = time.monotonic()
last_cpu = None

def stat(path):
    raw = open(path).read()
    fields = raw[raw.rfind(')') + 2:].split()
    return {'ticks': int(fields[11]) + int(fields[12]),
            'start': int(fields[19]), 'threads': int(fields[17]),
            'rss_mib': int(fields[21]) * PAGE / 1048576}

while True:
    now = time.monotonic()
    if now - last_scan >= 5:
        targets = {}
        for entry in os.scandir('/proc'):
            if not entry.name.isdigit():
                continue
            try:
                args = open(entry.path + '/cmdline', 'rb').read().replace(b'\0', b' ').decode()
                root = os.readlink(entry.path + '/root')
                name = next((n for n in ('move_base', 'coverage_manager', 'laserMapping',
                            'fast_lio_map_localizer', 'hybrid_teb_command_mux')
                             if '__name:=' + n + ' ' in args), None)
                if name and root == ROOT + '/rootfs':
                    targets[int(entry.name)] = name
                elif ROOT + '/bpu_perception_20260906/tools/inference_service.py' in args:
                    if 'python' in args.split()[0]:
                        targets[int(entry.name)] = 'bpu_inference'
            except (OSError, ValueError, IndexError):
                pass
        last_scan = now
    cpu = list(map(int, open('/proc/stat').readline().split()[1:9]))
    total, idle = sum(cpu), cpu[3] + cpu[4]
    busy = None if last_cpu is None else 100 * (1 - (idle-last_cpu[1]) / max(1, total-last_cpu[0]))
    processes = []
    new_previous = {}
    for pid, name in targets.items():
        try:
            current = stat('/proc/%s/stat' % pid)
            key = (pid, current['start'])
            old = previous.get(key)
            new_previous[key] = current['ticks']
            item = dict(pid=pid, name=name, **current)
            item['cpu_pct'] = None if old is None else round((current['ticks']-old)/HZ/(now-last_time)*100, 2)
            if name == 'move_base':
                threads = []
                for entry in os.scandir('/proc/%s/task' % pid):
                    try:
                        thread = stat(entry.path + '/stat')
                        tk = (pid, int(entry.name), thread['start'])
                        before = previous.get(tk)
                        new_previous[tk] = thread['ticks']
                        pct = None if before is None else round((thread['ticks']-before)/HZ/(now-last_time)*100, 2)
                        if before is None or pct:
                            threads.append(dict(tid=int(entry.name), start=thread['start'], ticks=thread['ticks'], cpu_pct=pct))
                    except OSError:
                        pass
                item['threads_active_or_new'] = threads
            processes.append(item)
        except (OSError, ValueError):
            pass
    print(json.dumps(dict(ts=time.time(), monotonic=now, interval_sec=now-last_time,
                          cores=os.cpu_count(), system_busy_pct=busy, processes=processes)), flush=True)
    previous, last_cpu, last_time = new_previous, (total, idle), now
    time.sleep(0.25)
