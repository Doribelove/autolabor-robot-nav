#!/usr/bin/env bash
set -euo pipefail
cd /home/slam/robot_j6m_ws_navigation_20260907
source scripts/load_config.sh
source scripts/setup_env.sh
exec python3 -u validation/coverage_live_20260907/monitor.py
