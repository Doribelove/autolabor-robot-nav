#!/usr/bin/env python3
"""Summarize a snapshot while the independent recorder continues."""
import collections
import datetime
import json
import statistics
from pathlib import Path

here = Path(__file__).resolve().parent
run = Path((here / 'latest_run.txt').read_text().strip())
if not (run / 'latest.json').exists():
    print(json.dumps(dict(state='waiting for ROS master / first samples', run=str(run))))
    raise SystemExit(0)

def rows(name):
    result = []
    with open(str(run / name)) as source:
        for line in source:
            try:
                result.append(json.loads(line))
            except ValueError:  # A concurrent final write can be incomplete.
                pass
    return result

events = rows('events.jsonl')
cpu = rows('j6m_cpu.jsonl')
latest = json.loads((run / 'latest.json').read_text())
process = collections.defaultdict(list)
for row in cpu:
    for item in row['processes']:
        if item['cpu_pct'] is not None:
            process[item['name']].append(item['cpu_pct'])
velocity = collections.defaultdict(lambda: dict(count=0, nonzero=0, max_abs=[]))
for event in events:
    if event['kind'] == 'heartbeat':
        for topic, value in event['velocity'].items():
            item = velocity[topic]
            item['count'] += value['count']
            item['nonzero'] += value['nonzero']
            item['max_abs'] = [max(a,b) for a,b in zip(
                item['max_abs'] or [0]*len(value['max_abs']), value['max_abs'])]
localization = collections.Counter()
for event in events:
    if event.get('topic') == '/fast_lio/localization_status' and 'msg' in event:
        localization[event['msg']['data'].split(';')[0]] += 1
busy = [row['system_busy_pct'] for row in cpu if row['system_busy_pct'] is not None]
odom = [e['msg']['twist']['twist'] for e in events
        if e.get('topic') == '/odom' and e['kind'] == 'odometry']
summary = dict(
    start=datetime.datetime.fromtimestamp(events[0]['ts']).isoformat(),
    end=datetime.datetime.fromtimestamp(events[-1]['ts']).isoformat(),
    duration_sec=round(events[-1]['ts']-events[0]['ts'], 2),
    cpu_samples=len(cpu),
    system_busy_pct=dict(mean=statistics.mean(busy), min=min(busy), max=max(busy)),
    process_cpu_pct={k: dict(mean=round(statistics.mean(v), 2), max=max(v))
                     for k,v in process.items()},
    move_base_thread_counts=sorted(set(x['threads'] for c in cpu
                                       for x in c['processes'] if x['name']=='move_base')),
    velocity=dict(velocity),
    odom=dict(samples=len(odom), max_abs_linear_x=max((abs(x['linear']['x']) for x in odom), default=0),
              max_abs_angular_z=max((abs(x['angular']['z']) for x in odom), default=0)),
    localization_states=dict(localization),
    coverage={k: latest['latest']['/coverage/status'][k] for k in
              ('state','detail','localized','batch_id','active','watchdog_motion_enabled')},
    first_entry=latest['latest'].get('/coverage/first_entry_path'),
    action_events=[dict(topic=e['topic'], ts=e['ts']) for e in events if e['kind']=='action'],
    rosout_problem_messages=sorted(set(e['msg']['msg'] for e in events
                                     if e['kind']=='rosout' and e['msg']['level']>=4)),
    map=latest['latest'].get('/autolabor_operator_gui/map_display_status'),
    collector_errors=[e for e in events if e['kind'].endswith('error') or e['kind']=='cpu_collector_exit'])
(run / 'summary_snapshot.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
print(json.dumps(summary, ensure_ascii=False, indent=2))
