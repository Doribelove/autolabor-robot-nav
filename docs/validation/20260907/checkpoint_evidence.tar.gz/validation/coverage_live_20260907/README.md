# 覆盖实验只读记录器

从候选工作区执行。私有 tmux 保证记录器不依赖临时终端；没有固定到期时间。

```bash
tmux -S runtime/run/coverage_monitor.tmux.sock new-session -d -s coverage-monitor \
  './scripts/optimized.sh run bash validation/coverage_live_20260907/start.sh >validation/coverage_live_20260907/monitor_console.log 2>&1'
```

查看 `latest_run.txt` 找到本次数据目录。`latest.json` 每秒原子更新；`events.jsonl`
记录 ROS 状态变化、路径变化（完整路径）、action、异常日志和每秒零速统计；
`j6m_cpu.jsonl` 每 250 ms 保存 J6M 总体 CPU、候选进程及 move_base 各活跃/新增线程。
100% 进程 CPU 对应单核，六核总体 busy 归一化到 100%；极短线程可能位于两次采样之间。
不依据线程名推断 Hybrid 搜索，必须结合 action 的时间窗口。时间字段含本机接收时刻。

暂停记录器（不停止机器人）：

```bash
tmux -S runtime/run/coverage_monitor.tmux.sock send-keys -t coverage-monitor C-c
```

完整导航冷启动后应重新启动记录器，确保重新向新 ROS master 注册订阅。
停机、构建、部署窗口不能与实验 CPU 基线混算。生成当前快照统计：

```bash
python3 validation/coverage_live_20260907/summarize.py
```

`can_probe.py` 是额外的 60 秒只读原始 CAN/命令到达间隔采样，不能追溯启动前丢失的帧。
以上工具都不调用控制服务、不发布初值/目标/速度。后台采集不会自动修复问题，也不会
在助手会话结束后主动发送通知；后续可依据连续记录检查异常。
