#!/usr/bin/env python3
"""60 s read-only capture of command arrival gaps and VCU frames."""
import json
import threading
import time
from pathlib import Path
import roslib.message
import rospy

run = Path((Path(__file__).parent / 'latest_run.txt').read_text().strip())
output = open(str(run / 'can_probe.jsonl'), 'a', buffering=1)
lock = threading.Lock()
previous = {}
counts = {}
max_gaps = {}

def plain(msg):
    if isinstance(msg, (list, tuple)):
        return [plain(x) for x in msg]
    if isinstance(msg, bytes):
        return list(msg)
    if hasattr(msg, '__slots__'):
        return {slot: plain(getattr(msg, slot)) for slot in msg.__slots__}
    return msg

def cb(msg, topic):
    with lock:
        now = time.monotonic()
        gap = None if topic not in previous else now - previous[topic]
        previous[topic] = now
        counts[topic] = counts.get(topic, 0) + 1
        max_gaps[topic] = max(max_gaps.get(topic, 0), gap or 0)
        output.write(json.dumps(dict(ts=time.time(), monotonic=now, topic=topic,
                                     gap_sec=gap, msg=plain(msg))) + '\n')

rospy.init_node('coverage_vcu_passive_probe', anonymous=True)
topics = dict(rospy.get_published_topics())
subs = []
for topic in ('/cmd_vel', '/cmd_vel_safe', '/canbus_msg', '/m2_driver/control_timeout',
              '/m2_driver/chassis_info', '/m2_driver/chassis_monitor',
              '/m2_driver/left_wheel_vel', '/m2_driver/right_wheel_vel'):
    if topic in topics:
        subs.append(rospy.Subscriber(topic, roslib.message.get_message_class(topics[topic]),
                                    cb, callback_args=topic, queue_size=1000))
start = time.time()
time.sleep(60)
with lock:
    result = dict(start=start, end=time.time(), counts=counts, max_arrival_gap_sec=max_gaps)
    (run / 'can_probe_summary.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
