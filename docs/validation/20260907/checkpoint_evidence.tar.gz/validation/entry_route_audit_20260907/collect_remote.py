"""Read-only September log inventory; run on J6M via ssh stdin."""
import collections
import hashlib
import json
import re
import sys
from pathlib import Path

ROOTS = [
    '/map/autolabor_runtime/logs/dual_host',
    '/map/robot_j6m_optimized_20260905/logs/dual_host',
    '/map/robot_j6m_navigation_20260907/logs/dual_host',
]
PATTERNS = {
    'route_selected': r'coverage selected .*route|coverage selected Hybrid',
    'entry_completed': r'coverage connector 1 accepted|coverage .*entry.*completed',
    'sweep_completed': r'coverage sweep .*completed',
    'global_no_path': r'Failed to get a plan|Failed to create a plan|Failed to find a path|no path to the first|NO PATH|Failed to get a global plan',
    'outside_map': r'outside the global costmap|off the global costmap|start position.*outside|goal.*occupied|start.*occupied',
    'hybrid_failure': r'Hybrid.*(?:failed|timeout|exceeded|no path|exhausted)|hybrid.*(?:timeout|exceeded)',
    'policy_rejection': r'forward detour|entry-alignment.*rejected',
    'gear_rejection': r'violated the fixed-gear contract',
    'no_progress': r'less than .*progress|no.progress|no feasible detour|exceeded.*timeout',
    'motion_gate': r'main motion gate is disabled|motion_enabled.*[Ff]alse',
    'initial_pose': r'initial pose|initialpose|WAITING_INITIAL_POSE|waiting for.*transform|Timed out waiting for transform',
    'localization_bad': r'localization.*(?:LOST|DEGRADED|not LOCALIZED)|known.map.*(?:LOST|DEGRADED)',
    'navfn': r'Navfn|navfn|CoverageGlobalPlanner.*initialized',
    'parameter_sync': r'planning defaults|TEB.*(?:restor|configuration|parameter)',
    'stale_costmap': r'observation buffer.*(?:updated|stale)|Map update loop missed',
    'exception': r'Traceback|coverage.*exception|coverage.*failed',
}
regexes = {k: re.compile(v, re.I) for k, v in PATTERNS.items()}
ansi = re.compile(r'\x1b\[[0-9;]*[A-Za-z]|\x1b\][^\x07]*\x07')
output = []
for root in ROOTS:
    for session in sorted(Path(root).glob('202609*')):
        record = {'root': root, 'session': session.name, 'files': [], 'releases': [], 'startup_parameters': {}}
        releases = set()
        files = [session / 'console.log']
        files += sorted(session.glob('*/coverage_manager-*.log'))
        files += sorted(session.glob('*/rosout.log*'))
        if '--only-rotated' in sys.argv:
            files = [p for p in files if p.name.startswith('rosout.log.')]
            if not files:
                continue
        for path in files:
            if not path.is_file():
                continue
            raw = path.read_bytes()
            lines = raw.decode(errors='replace').splitlines()
            counts = collections.Counter()
            samples = collections.defaultdict(list)
            tail = {}
            manager_events = []
            for number, raw_line in enumerate(lines, 1):
                if '/releases/' in raw_line:
                    releases.update(re.findall(r'/releases/(2026\d{4}_\d{6})/', raw_line))
                line = ansi.sub('', raw_line)
                # ROS rosout prefixes enumerate all published topics. Do not
                # match Hybrid topic names against unrelated error messages.
                payload = line
                topic_start = line.find('[topics: ')
                if topic_start >= 0:
                    message_start = line.find('] ', topic_start)
                    if message_start >= 0:
                        payload = line[message_start + 2:]
                        line = line[:topic_start] + payload
                if path.name == 'console.log':
                    match = re.match(r'\s*\* (/(?:coverage_manager|move_base)/[^:]+): (.*)', line)
                    if match:
                        record['startup_parameters'][match[1]] = match[2]
                if path.name.startswith('coverage_manager') and re.match(r'\[rosout\]', line):
                    manager_events.append({'line': number, 'text': line})
                for kind, pattern in regexes.items():
                    if pattern.search(payload):
                        counts[kind] += 1
                        item = {'line': number, 'text': line[:2400]}
                        if len(samples[kind]) < 4:
                            samples[kind].append(item)
                        tail[kind] = item
            for kind, item in tail.items():
                if item not in samples[kind]:
                    samples[kind].append(item)
            record['files'].append({'path': str(path), 'bytes': len(raw),
                'sha256': hashlib.sha256(raw).hexdigest(), 'lines': len(lines),
                'counts': dict(counts), 'samples': dict(samples),
                'manager_events': manager_events})
        record['releases'] = sorted(releases)
        output.append(record)
print(json.dumps({'patterns': PATTERNS, 'sessions': output}, ensure_ascii=False, indent=2))
