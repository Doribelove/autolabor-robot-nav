"""Produce a per-start index, without treating log matches as success rates."""
import collections
import csv
import datetime
import json
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent
data = json.loads((BASE / 'remote_log_inventory.json').read_text())
rows = []
event_lines = []
for session in data['sessions']:
    events = [(f['path'], e) for f in session['files']
              for e in f['manager_events']]
    route_count = sum(bool(re.search(r'coverage selected .*route|coverage selected Hybrid', e['text']))
                      for _, e in events)
    entries = sum(bool(re.search(r'coverage connector 1 accepted', e['text']))
                  for _, e in events)
    sweeps = sum(bool(re.search(r'coverage sweep .*completed', e['text']))
                 for _, e in events)
    counts = collections.Counter()
    for file in session['files']:
        if Path(file['path']).name.startswith('rosout.log'):
            counts.update(file['counts'])
    params = session['startup_parameters']
    row = {
        'session_cst': session['session'], 'remote_root': session['root'],
        'release_from_logs': '|'.join(session['releases']),
        'geometry_selection_log_count': route_count,
        'connector_1_accepted_log_count': entries,
        'sweep_completed_log_count': sweeps,
        'global_no_path_log_count': counts.get('global_no_path', 0),
        'fixed_gear_rejection_log_count': counts.get('gear_rejection', 0),
        'hybrid_failure_log_count': counts.get('hybrid_failure', 0),
        'startup_teb_lookahead': params.get('/move_base/TebLocalPlannerROS/max_global_plan_lookahead_dist', ''),
        'startup_hybrid_lookahead': params.get('/coverage_manager/hybrid_transit_lookahead_dist_m', ''),
        'startup_manager_max_speed': params.get('/coverage_manager/default_max_speed_mps', ''),
        'startup_teb_max_vel_x': params.get('/move_base/TebLocalPlannerROS/max_vel_x', ''),
        'startup_entry_single_topology': params.get('/coverage_manager/entry_navfn_single_topology', ''),
        'startup_direct_hybrid': params.get('/coverage_manager/direct_hybrid_to_final_goal', ''),
        'startup_hybrid_no_progress_sec': params.get('/coverage_manager/hybrid_no_progress_timeout_sec', ''),
    }
    rows.append(row)
    event_lines.append('\n===== {} | {} | {} ====='.format(
        session['session'], session['root'], '|'.join(session['releases'])))
    for source, event in events:
        text = event['text']
        match = re.search(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}', text)
        cst = ''
        if match:
            date = datetime.datetime.strptime(match.group(), '%Y-%m-%d %H:%M:%S,%f')
            cst = (date + datetime.timedelta(hours=8)).isoformat(sep=' ', timespec='milliseconds')
        event_lines.append('{} CST | {}:{} | {}'.format(cst, source, event['line'], text))
with (BASE / 'restart_index.csv').open('w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
(BASE / 'coverage_events.txt').write_text('\n'.join(event_lines) + '\n')
summary = {'sessions': len(rows), 'files': sum(len(s['files']) for s in data['sessions']),
           'source_bytes': sum(f['bytes'] for s in data['sessions'] for f in s['files']),
           'sessions_by_root': dict(collections.Counter(r['remote_root'] for r in rows)),
           'sessions_by_date': dict(sorted(collections.Counter(r['session_cst'][:8] for r in rows).items())),
           'sessions_with_geometry_selection_logs': sum(r['geometry_selection_log_count'] > 0 for r in rows),
           'note': 'Counts are log matches, not independent trials or success rates. Startup parameters precede Qt and task overrides.'}
(BASE / 'inventory_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
print(json.dumps(summary, ensure_ascii=False))
for row in rows:
    print(row['session_cst'], row['release_from_logs'], 'geometry', row['geometry_selection_log_count'],
          'entry1', row['connector_1_accepted_log_count'], 'sweep', row['sweep_completed_log_count'],
          'no_path', row['global_no_path_log_count'], 'gear', row['fixed_gear_rejection_log_count'])
